
                let Discord;
                let Database;
                if(typeof window !== "undefined"){
                    Discord = DiscordJS;
                    Database = EasyDatabase;
                } else {
                    Discord = require("discord.js");
                    Database = require("easy-json-database");
                }
                const delay = (ms) => new Promise((resolve) => setTimeout(() => resolve(), ms));
                const s4d = {
                    Discord,
                    client: null,
                    tokenInvalid: false,
                    reply: null,
                    joiningMember: null,
                    database: new Database("./db.json"),
                    checkMessageExists() {
                        if (!s4d.client) throw new Error('You cannot perform message operations without a Discord.js client')
                        if (!s4d.client.readyTimestamp) throw new Error('You cannot perform message operations while the bot is not connected to the Discord API')
                    }
                };
                s4d.client = new s4d.Discord.Client({
                    fetchAllMembers: true
                });
                s4d.client.on('raw', async (packet) => {
                    if(['MESSAGE_REACTION_ADD', 'MESSAGE_REACTION_REMOVE'].includes(packet.t)){
                        const guild = s4d.client.guilds.cache.get(packet.d.guild_id);
                        if(!guild) return;
                        const member = guild.members.cache.get(packet.d.user_id) || guild.members.fetch(d.user_id).catch(() => {});
                        if(!member) return;
                        const channel = s4d.client.channels.cache.get(packet.d.channel_id);
                        if(!channel) return;
                        const message = channel.messages.cache.get(packet.d.message_id) || await channel.messages.fetch(packet.d.message_id).catch(() => {});
                        if(!message) return;
                        s4d.client.emit(packet.t, guild, channel, message, member, packet.d.emoji.name);
                    }
                });
                
var requested;

s4d.client.login('ODY1MzkyNTYzNzMzNTI4NjI2.YPDVoQ.-HV5B2cHZL2W8v_IRAGO-0PJ2qI').catch((e) => { s4d.tokenInvalid = true; s4d.tokenError = e; });

s4d.client.on('message', async (s4dmessage) => {
  if ((s4dmessage.content) == '?help') {
    s4dmessage.channel.send(String('**Here are some commands I have so far, wringly will add more in the future**'));
    
    s4dmessage.channel.send(String('?funny -- Does the funny'));

        s4dmessage.channel.send(String('?logo -- Sends the Risen Church logo'));
    
    s4dmessage.channel.send(String('?requestLOA -- Must be staff to do this!'));

  }

});

s4d.client.on('message', async (s4dmessage) => {
  if ((s4dmessage.content) == '?funny') {
    for (var count = 0; count < 10; count++) {
      await delay(Number(1) * 1000);
      s4dmessage.channel.send(String('FUNNY HAHAHA'));
    }
  }

});

s4d.client.on('message', async (s4dmessage) => {
    if ((s4dmessage.content) == '?requestLOA') {
        if ((s4dmessage.member).hasPermission('CHANGE_NICKNAME')) {
            s4dmessage.channel.send(String('Are you sure you want a break?'));
            requested = true;
        } else {
            s4dmessage.channel.send(String('You are not a staff member!'));
        }
    }

});

s4d.client.on('message', async (s4dmessage) => {
  if ((s4dmessage.content) == '?logo') {
    s4dmessage.channel.send(String('https://t4.rbxcdn.com/a1ac505e87f6ca6f40e6350d42d9f8a0'));
  }

});

s4d.client.on('ready', async () => {
    s4d.client.user.setActivity(String('| Join Risen Church! | ?help'));

});


s4d.client.on('message', async (s4dmessage) => {
    if (requested == true) {
      if (String((s4dmessage.author) != 'Risen Church Bot')) {
        if ((s4dmessage.content).length == 'Yes'.length) {
            s4dmessage.channel.send(String('Alright I dmed vex and asked if you can have LOA!'))

            const user = await s4d.client.users.fetch("472036858692501535").catch(() => null);

            if (!user) return message.channel.send("User not found:(");

            await user.send(String(s4dmessage.author).concat(" asked if they could go on LOA")).catch(() => {
              message.channel.send("User has DMs closed or has no mutual servers with the bot:(");
            });

            requested = false;
        } else if ((s4dmessage.content).length < 'Yes'.length) {
          s4dmessage.channel.send(String('Aight then hmu lmk if u need a break I gochu 🤙🤙🤙🤙'));
          requested = false;
        }
      }
    }

});

                s4d;
            